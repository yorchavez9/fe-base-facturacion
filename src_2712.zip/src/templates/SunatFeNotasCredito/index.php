
<div class="sunatFeNotas index content">
    <div class="table-responsive gw-table">
        <table class="table table-sm table-striped table-hover">
            <thead>
            <tr>
                <th>F. emisión</th>
                <th> Serie y correlativo </th>
                <th>Documento</th>
                <th> Motivo y estado </th>
                <th style="width: 150px;" colspan="2">Moneda y Monto</th>
                <th class="actions">Acciones</th>
            </tr>
            </thead>
            <tbody id="table_notas">
            </tbody>
        </table>
    </div>
</div>


<?php   echo $this->Element('modal_descargar_enviar');
echo $this->Element('modal_factura_nota');
