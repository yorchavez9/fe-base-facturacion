<div class="row">
    <div class="col">
        <legend>Limpieza del Sistema</legend>
    </div>
</div>


<div class="row">
    <div class="col">
        <a href="javascript:limpiarClientes()" class="btn btn-sm btn-primary mb-2"><i class="fa fa-fw fa-trash"></i> Clientes</a>
        <a href="javascript:limpiarDirectorio()" class="btn btn-sm btn-primary mb-2"><i class="fa fa-fw fa-trash"></i> Directorios</a>
        <a href="javascript:limpiarProductos()" class="btn btn-sm btn-primary mb-2"><i class="fa fa-fw fa-trash"></i> Productos</a>
        <a href="javascript:limpiarDocumentosElectronicos()" class="btn btn-sm btn-primary mb-2"><i class="fa fa-fw fa-trash"></i> Ventas & Doc. Electronicos</a>
        <a href="javascript:limpiarSistema()" class="btn btn-sm btn-danger mb-2"><i class="fa fa-fw fa-trash"></i> Limpiar Todo</a>
    </div>
</div>