$(document).ready(function(){


    // $("[name=periodo]").datepicker({
    //     locale: 'es-es',
    //     uiLibrary: 'bootstrap4',
    //     format: 'yyyy'
    // });

});
