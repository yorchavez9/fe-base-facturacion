<div   style="border: 2px solid #E1E6EA;padding: 10px 15px 10px 15px;max-width: 600px;justify-content: center"  >
    <div>
        <img style=" max-height: 70px;margin-left: auto;margin-right: auto" src="cid:logo" alt="logo"  />
    </div>
    <p>
        Se registró el siguiente usuario para el host: <a href="<?= $cliente_url ?>"><?= $cliente_url ?></a>
        <br>
        <label style="display: inline-block;max-width:80px;width: 80px"> <b>Usuario</b></label>
        : <?= $usuario_nombre?>
        <br/>
        <br>
        <label style="display: inline-block;max-width:80px;width: 80px"><b>Clave</b></label>
        : <?= $usuario_clave ?><br/>
        <br>
        <br>
    </p>
</div>
