<nav class="gw-footer" style="background: <?= $global_brand_data['global_color_bg1']; ?>">
    <div class="row px-3">
        <div class="col-sm-3 text-left">
            Sistema de Cotizaciones
        </div>
        <div class="col-sm-6 text-center">

        </div>
        <div class="col-sm-3 text-right">
            <?= $datos_empresa['razon_social']?>
        </div>
    </div>
</nav>
