<div class="container">
    <div class="row py-5">
        <div class="col-sm-4 text-center">
            <a href="<?= $this->Url->Build(['controller' => 'Reportes', 'action' => 'productosVendidos']) ?>">
                <figure class="figure">
                    <img class="figure-img img-fluid" src="<?= $this->Url->Build("/media/iconos/mercaderia2.png") ?>" width="128px" alt="">
                    <figcaption class="figure-caption text-center">
                        Productos Vendidos
                    </figcaption>
                </figure>
            </a>
        </div>
    </div>
</div>
