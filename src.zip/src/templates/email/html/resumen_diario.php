<div style="text-align: center; width: 100%">
	<?= $this->Html->image('media/email/saludo.png', ['fullBase' => true]); ?>
	<?= $this->Html->image('media/default_logo.png', ['fullBase' => true]); ?>
    Hola, tu Sistema de Cotizaciones te envía un ZIP con tus comprobantes emitidos el día de hoy <?= date("d-m-Y") ?>, también un Excel y un PDF con tus ventas.
</div>
