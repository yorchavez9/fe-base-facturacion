<div style="text-align: center; width: 100%">
	<?= $this->Html->image('/media/default_logo.png', ['fullBase' => true]); ?>
	<br>
	<?= $this->Html->image('/media/email/saludo.png', ['fullBase' => true]); ?>
    Hola, tu sistema Gfast te envía un Excel y  un PDF con tus ventas ademas un ZIP con tus comprobantes emitidos del <?= date("01-m-Y") ?> al <?= date("t-m-T") ?>;
</div>
