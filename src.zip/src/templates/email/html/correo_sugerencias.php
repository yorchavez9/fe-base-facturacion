<div   style="border: 2px solid #E1E6EA;padding: 10px 15px 10px 15px;max-width: 600px;justify-content: center"  >
    
    <p>
        &nbsp;&nbsp;&nbsp;  <b>Tenemos una nueva sugerencia</b>
    </p>
    <hr color="E1E6EA">
    <p>
        Los datos del usuario son:
        <br>
        <br>
        <label style="display: inline-block;width: 150px !important">Url</label>
        : <?=$data['system_url']?>
        <br>
        <label style="display: inline-block;width: 150px !important">Usuario </label>
        : <?=$data['user_usuario']?>
        <br>
        <label style="display: inline-block;width: 150px !important">Celular </label>
        : <?=$data['user_whatsapp'] ?>
        <br>
        <br>
        <label style="display: inline-block;width: 150px !important">Sugerencia </label>
        : 
        <br>
        
        <span style="color: #9E9E9E">
            <small>
             <?=$data['sugerencia'] ?>
            </small>
        </span>
    </p>



</div>