$(document).ready(function(){
    $("#whatsapp").mask("###########");
});
