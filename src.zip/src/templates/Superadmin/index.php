<div class="row">
    <div class="col-md-12">
        <?= $this->Html->Link("generar sunat fe facturas", ['action' => 'regenerarRegistrosFactura'])   ?>
    </div>
</div>
