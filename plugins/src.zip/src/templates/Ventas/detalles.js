$(document).ready(function(){
    $("#btnDescargar").click(function(e){
        e.preventDefault()
        ModalDescargarEnviar.Abrir(cpe_tipo,cpe_id);
    })
})


var VentaDetalle = {

    consultarValidezCpe  : function (element){

        // TODO poner animacion de "enviando"
        var factura_id = $(element).attr("data-comprobante-id");

        var link_icono = $(element).find("i")[0];
        VentaDetalle.setLinkLoad(link_icono,element,"fa-exchange-alt");


        var url = `${base}sunat-fe-facturas/api-consulta-validez-cpe/${factura_id}`;
        $.ajax({
            url     :   url,
            data    :   '',
            type    :   'POST',
            success :   function (data, status, xhr) {

                alert(data.message);
                VentaDetalle.stopLinkLoad(link_icono,element,"fa-exchange-alt");

            },
            error: function (xhr, ajaxOptions, thrownError) {
                alert(xhr.status);
                alert(thrownError);

                VentaDetalle.stopLinkLoad(link_icono,element,"fa-exchange-alt");

            }

        });
    },
    setLinkLoad   :   function(element,element_parent,class_to_replace)
    {
        $(element).removeClass(`${class_to_replace}`);
        $(element).addClass('spinner-border');
        $(element).addClass('spinner-border-sm');
        $(element_parent).css("pointer-events","none");
    },
    stopLinkLoad      :   function(element,element_parent,class_to_set)
    {
        $(element).removeClass('spinner-border');
        $(element).removeClass('spinner-border-sm');
        $(element).addClass(`${class_to_set}`);
        $(element_parent).css("pointer-events","auto");
    },
    Imprimir: function (formato , venta_id) {
        var endpoint = `${base}sunat-fe-facturas/api-imprimir-pdf/${venta_id}/${formato}`;
        $.ajax({
            url     :   endpoint,
            data    :   '',
            type    :   'GET',

            success :   function (data, status, xhr) {// success callback function
                console.log(data);
                if(data.success)
                {
                    printJS({printable: data.data, type: 'pdf', base64: true, modalMessage: 'Cargando Documento'});

                }else{
                    alert(data.message);
                }

            },
            error: function (xhr, ajaxOptions, thrownError) {
                alert(xhr.status);
                alert(thrownError);
            }
        });

    },



}
