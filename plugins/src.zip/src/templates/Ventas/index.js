$(document).ready(function(){

    ModalDescargarEnviar.Init();
    ModalImprimirVenta.Init();

    $("[name=fecha_ini]").datepicker({
        locale: 'es-es',
        format: 'yyyy-mm-dd',
        uiLibrary: 'bootstrap4'
    });
    $("[name=fecha_fin]").datepicker({
        locale: 'es-es',
        format: 'yyyy-mm-dd',
        uiLibrary: 'bootstrap4'
    });

    $('[name=factura]').mask('AAAA-00000000');


    $(function () {
        $('[data-toggle="popover"]').popover()
    })


});

function abrirModalFactura() {
    $('[name=factura]').val('');
    $('#modalFactura').modal('show');
}


function abrirModalAnulacionFactura(venta_id, com_baja, doc) {
    $('#modalAnularFactura').modal('show');
    $('[name=a_venta_id]').val(venta_id);
    $('#f_serie_correlativo').html(doc);

    if (com_baja == 1) {
        $('#btn_com_baja').attr('disabled', false);
    } else {
        $('#btn_com_baja').attr('disabled', true);
    }
}

function abrirModalAnulacionBoleta(venta_id, doc) {
    $('#modalAnularBoleta').modal('show');
    $('[name=boleta_venta_id]').val(venta_id);
    $('#b_serie_correlativo').html(doc);
}

function abrirModalModificacion(venta_id, doc) {
    $('#modalModificar').modal('show');
    $('[name=b_venta_id]').val(venta_id);
    $('#m_serie_correlativo').html(doc);
}

var MisVentas = {

    anularNotaVenta         : function (venta_id){
        var r = prompt("Por favor, ingrese el motivo de la anulación");
        if (r == null){return false;}

        $.ajax({
            url     :   base + "ventas/api-anular-nota-venta",
            data    :   {
                venta_id : venta_id,
                motivo : r
            },
            type    :   'post',

            success :   function (data, status, xhr) {// success callback function
                console.log(data);
                if (data.success){
                    location.reload()
                }else{
                    alert(data.message);
                }
            },
            error: function (xhr, ajaxOptions, thrownError) {
                alert(xhr.status);
                alert(thrownError);
            }
        });
    },


    eliminar_nota_factura: function () {
        var venta_id = $('[name=a_venta_id]').val();
        location.href = base + "sunat-fe-notas-credito/nota-credito-anular/" + venta_id;
    },

    eliminar_nota_boleta: function () {
        var venta_id = $('[name=boleta_venta_id]').val();
        location.href = base + "sunat-fe-notas-credito/nota-credito-anular/" + venta_id;
    },

    modificar: function (tipo) {
        var venta_id = $('[name=b_venta_id]').val();
        if (tipo == "credito") {
            location.href = base + "sunat-fe-notas-credito/nota-credito/" + venta_id;
        } else {
            location.href = base + "sunat-fe-notas/nota-debito/" + venta_id;
        }

    },


    enviarComunicacionBaja    : function(){
        var venta_id = $('[name=a_venta_id]').val();
        var r = prompt("Por favor, ingrese el motivo de la anulación");
        if (r == null){return false;}

        $.ajax({
            url     :   base + "sunat-fe-comunicacion-bajas/enviar/",
            data    :   {
                venta_id : venta_id,
                motivo : r
            },
            type    :   'post',

            success :   function (data, status, xhr) {// success callback function
                console.log(data);
                if (data.success){
                    location.reload()
                }else{
                    alert(data.message);
                }
            },
            error: function (xhr, ajaxOptions, thrownError) {
                alert(xhr.status);
                alert(thrownError);
            }
        });
    },

    enviarAnulacionBoleta    : function(){
        var venta_id = $('[name=boleta_venta_id]').val();

        $.ajax({
            url     :   base + "sunat-fe-facturas/api-anular-boleta/",
            data    :   {
                venta_id : venta_id
            },
            type    :   'post',

            success :   function (data, status, xhr) {// success callback function
                console.log(data);
                if (data.success){
                    location.reload()
                }else{
                    alert(data.message);
                }
            },
            error: function (xhr, ajaxOptions, thrownError) {
                alert(xhr.status);
                alert(thrownError);
            }
        });
    },
    consultarCdr    :   function()
    {
        var venta_id = $(element).attr("data-venta-id");

        var link_icono = $(element).find("i")[0];
        MisVentas.setLinkLoad(link_icono,element,"fa-upload");

        var url = `${base}sunat-fe-facturas/consultar-cdr`;
        $.ajax({
            url: url,
            data: {
                venta_id: venta_id
            },
            type: 'POST',
            success: function (data, status, xhr) {
                console.log(data)
                if (data.success) {
                    alert(data.message);

                } else {
                    alert(data.message);
                }

                MisVentas.stopLinkLoad(link_icono,element,"fa-upload");
            },
            error: function (xhr, ajaxOptions, thrownError) {
                alert(xhr.status);
                alert(thrownError);

                MisVentas.stopLinkLoad(link_icono,element,"fa-upload");

            }

        });
    }

};
