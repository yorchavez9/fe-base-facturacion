<div   style="border: 2px solid #E1E6EA;padding: 10px 15px 10px 15px;max-width: 600px;justify-content: center"  >
    <p>
        Alerta con el certificado digital en: <a href="<?= $cliente_url ?>" target="_blank"><?= $cliente_url ?></a>
        <br>        
        <br>
        <?= $mensaje ?>
    </p>
</div>
