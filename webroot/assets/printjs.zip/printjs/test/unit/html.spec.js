import Html from '../../src/js/html'

describe('Html', () => {
  it('has a method named print', () => {
    expect(typeof Html.print).toBe('function')
  })
})
