import {Chart, registerables} from '../dist/chart.esm';

Chart.register(...registerables);

export default Chart;
